import subprocess
import pytest
import os

INTERPRETER = 'python' # Замените на python3 при работе в Linux/macOS

def run_script(filename, input_data=None):
    if not os.path.exists(filename):
        return ""
    proc = subprocess.run(
        [INTERPRETER, filename],
        input='\n'.join(input_data if input_data else []),
        capture_output=True,
        text=True,
        encoding='utf-8',
        check=False
    )
    return proc.stdout.strip()

test_data = {
    'python_if_else': [
        (['1'], 'Weird'), (['4'], 'Not Weird'), (['3'], 'Weird'), (['6'], 'Weird'), (['22'], 'Not Weird')
    ],
    'arithmetic_operators': [
        (['3\n5'], '8\n-2\n15'), (['10\n5'], '15\n5\n50'), (['0\n0'], '0\n0\n0')
    ],
    'division': [
        (['3\n5'], '0\n0.6'), (['10\n2'], '5\n5.0'), (['7\n3'], '2\n2.3333333333333335')
    ],
    'loops': [
        (['3'], '0\n1\n4'), (['5'], '0\n1\n4\n9\n16'), (['1'], '0')
    ],
    'print_function': [
        (['3'], '123'), (['5'], '12345'), (['1'], '1')
    ],
    'second_score': [
        (['5\n2 3 6 6 5'], '5'), (['3\n1 1 1'], ''), (['4\n10 20 30 40'], '30')
    ],
    'nested_list': [
        (['5\nГарри\n37.21\nБерри\n37.21\nТина\n37.2\nАкрити\n41\nХарш\n39'], 'Берри\nГарри'),
        (['3\nАлекс\n10\nБоб\n20\nЧарли\n30'], 'Боб'),
        (['4\nА\n5\nБ\n5\nВ\n10\nГ\n10'], 'В\nГ')
    ],
    'lists': [
        (['4\nappend 1\nappend 2\ninsert 1 3\nprint'], '[1, 3, 2]'),
        (['3\nappend 5\npop\nprint'], '[]'),
        (['5\nappend 1\nappend 3\nappend 2\nsort\nprint'], '[1, 2, 3]')
    ],
    'swap_case': [
        (['Www.MosPolytech.ru'], 'wWW.mOSpOLYTECH.RU'),
        (['Pythonist 2'], 'pYTHONIST 2'), (['123 ABC abc'], '123 abc ABC')
    ],
    'split_and_join': [
        (['this is a string'], 'this-is-a-string'), (['hello   world'], 'hello-world'), (['single'], 'single')
    ],
    'anagram': [
        (['listen silent'], 'YES'), (['hello world'], 'NO'), (['abc cba'], 'YES')
    ],
    'metro': [
        (['2\n10 20\n15 25\n18'], '2'), (['1\n5 10\n15'], '0'), (['3\n0 5\n5 10\n10 15\n5'], '2')
    ],
    'minion_game': [
        (['BANANA'], 'Стюарт 12'), (['AEIOU'], 'Кевин 15'), (['BA'], 'Стюарт 2')
    ],
    'is_leap': [
        (['2000'], 'True'), (['1900'], 'False'), (['2024'], 'True'), (['2023'], 'False')
    ],
    'happiness': [
        (['3 2\n1 5 3\n3 1\n5 7'], '1'), (['2 1\n10 10\n10\n20'], '2'), (['1 1\n5\n1\n5'], '-1')
    ],
    'pirate_ship': [
        (['50 3\nGold 20 100\nSilver 30 120\nBronze 10 20'], 'Gold 20 100\nSilver 30 120'),
        (['10 2\nA 20 100\nB 10 10'], 'A 10 50.0'),
        (['100 1\nRock 200 50'], 'Rock 100 25.0')
    ],
    'matrix_mult': [
        (['2\n1 2\n3 4\n5 6\n7 8'], '19 22\n43 50'),
        (['2\n1 0\n0 1\n5 6\n7 8'], '5 6\n7 8'),
        (['2\n0 0\n0 0\n1 1\n1 1'], '0 0\n0 0')
    ]
}

def test_hello():
    assert run_script('hello.py') == 'Hello, World!'

@pytest.mark.parametrize("input_data, expected", test_data['python_if_else'])
def test_python_if_else(input_data, expected):
    assert run_script('python_if_else.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['arithmetic_operators'])
def test_arithmetic_operators(input_data, expected):
    assert run_script('arithmetic_operators.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['division'])
def test_division(input_data, expected):
    assert run_script('division.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['loops'])
def test_loops(input_data, expected):
    assert run_script('loops.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['print_function'])
def test_print_function(input_data, expected):
    assert run_script('print_function.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['second_score'])
def test_second_score(input_data, expected):
    assert run_script('second_score.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['nested_list'])
def test_nested_list(input_data, expected):
    assert run_script('nested_list.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['lists'])
def test_lists(input_data, expected):
    assert run_script('lists.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['swap_case'])
def test_swap_case(input_data, expected):
    assert run_script('swap_case.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['split_and_join'])
def test_split_and_join(input_data, expected):
    assert run_script('split_and_join.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['anagram'])
def test_anagram(input_data, expected):
    assert run_script('anagram.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['metro'])
def test_metro(input_data, expected):
    assert run_script('metro.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['minion_game'])
def test_minion_game(input_data, expected):
    assert run_script('minion_game.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['is_leap'])
def test_is_leap(input_data, expected):
    assert run_script('is_leap.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['happiness'])
def test_happiness(input_data, expected):
    assert run_script('happiness.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['pirate_ship'])
def test_pirate_ship(input_data, expected):
    assert run_script('pirate_ship.py', input_data) == expected

@pytest.mark.parametrize("input_data, expected", test_data['matrix_mult'])
def test_matrix_mult(input_data, expected):
    assert run_script('matrix_mult.py', input_data) == expected