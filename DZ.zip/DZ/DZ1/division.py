#4
def main():
    data = []
    while True:
        try:
            data.extend(input().split())
        except EOFError:
            break

    if len(data) >= 2:
        a, b = int(data[0]), int(data[1])
        if b != 0:
            print(a // b)
            print(a / b)
        else:
            print("Division by zero")


if __name__ == '__main__':
    main()