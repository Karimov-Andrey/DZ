#8
def main():
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break

    if not lines: return
    n = int(lines[0])
    students = []
    idx = 1

    for _ in range(n):
        if idx + 1 < len(lines):
            name = lines[idx]
            score = float(lines[idx + 1])
            students.append([name, score])
            idx += 2

    scores = sorted(list(set([s[1] for s in students])))
    if len(scores) > 1:
        target = scores[1]
        names = sorted([s[0] for s in students if s[1] == target])
        for name in names:
            print(name)


if __name__ == '__main__':
    main()