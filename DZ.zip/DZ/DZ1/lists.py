#9
def main():
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break

    if not lines: return
    n = int(lines[0])
    arr = []

    for i in range(1, min(n + 1, len(lines))):
        data = lines[i].split()
        cmd = data[0]
        if cmd == 'insert':
            arr.insert(int(data[1]), int(data[2]))
        elif cmd == 'print':
            print(arr)
        elif cmd == 'remove':
            arr.remove(int(data[1]))
        elif cmd == 'append':
            arr.append(int(data[1]))
        elif cmd == 'sort':
            arr.sort()
        elif cmd == 'pop':
            arr.pop()
        elif cmd == 'reverse':
            arr.reverse()


if __name__ == '__main__':
    main()