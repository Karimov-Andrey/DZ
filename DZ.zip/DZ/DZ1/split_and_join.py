#11
def main():
    try:
        s = input().strip()
        print("-".join(s.split()))
    except EOFError:
        pass

if __name__ == '__main__':
    main()