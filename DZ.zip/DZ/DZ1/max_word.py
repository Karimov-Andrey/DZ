#12
import re
def main():
    try:
        with open('example.txt', 'r', encoding='utf-8') as f:
            text = f.read()

        words = re.findall(r'[a-zA-Zа-яА-ЯёЁ]+', text)
        if not words: return

        max_len = max(len(w) for w in words)
        ans = []
        seen = set()

        for w in words:
            if len(w) == max_len and w.lower() not in seen:
                ans.append(w)
                seen.add(w.lower())

        for w in ans:
            print(w)

    except FileNotFoundError:
        print("Файл example.txt не найден")


if __name__ == '__main__':
    main()