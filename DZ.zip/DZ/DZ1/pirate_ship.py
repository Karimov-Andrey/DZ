#19
def main():
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break

    if not lines: return

    capacity, m = map(int, lines[0].split())

    items = []
    for i in range(1, m + 1):
        if i < len(lines):
            data = lines[i].split()
            items.append({
                'name': data[0], 'w': int(data[1]),
                'v': int(data[2]), 'ratio': int(data[2]) / int(data[1])
            })

    items.sort(key=lambda x: x['ratio'], reverse=True)

    for item in items:
        if capacity <= 0: break
        take_w = min(item['w'], capacity)
        if take_w == item['w']:
            w_out, v_out = item['w'], item['v']
        else:
            w_out, v_out = take_w, take_w * item['ratio']

        capacity -= take_w
        print(f"{item['name']} {w_out} {v_out}")


if __name__ == '__main__':
    main()