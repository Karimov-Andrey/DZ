#15
def main():
    try:
        n = int(input().strip())
        intervals = []
        for _ in range(n):
            a, b = map(int, input().split())
            intervals.append((a, b))
        T = int(input().strip())

        count = sum(1 for a, b in intervals if a <= T <= b)
        print(count)
    except EOFError:
        pass


if __name__ == '__main__':
    main()