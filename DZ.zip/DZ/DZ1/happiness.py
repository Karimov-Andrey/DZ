#18
def main():
    try:
        n, m = map(int, input().split())
        arr = input().split()
        A = set(input().split())
        B = set(input().split())

        happiness = 0
        for x in arr:
            if x in A:
                happiness += 1
            elif x in B:
                happiness -= 1

        print(happiness)
    except EOFError:
        pass


if __name__ == '__main__':
    main()