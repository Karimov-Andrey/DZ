#13
import csv


def main():

    sums = {'взрослый': 0.0, 'пенсионер': 0.0, 'ребёнок': 0.0, 'ребенок': 0.0}
    try:
        with open('products.csv', 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            for row in reader:
                row_str = ' '.join(row).lower()
                cat = None
                if 'взрослый' in row_str:
                    cat = 'взрослый'
                elif 'пенсионер' in row_str:
                    cat = 'пенсионер'
                elif 'ребёнок' in row_str or 'ребенок' in row_str:
                    cat = 'ребёнок'

                if cat:
                    for item in row:
                        try:
                            val = float(item.replace(',', '.'))
                            sums[cat] += val
                        except ValueError:
                            pass

        total_child = sums['ребёнок'] + sums['ребенок']
        print(f"{sums['взрослый']:.2f} {sums['пенсионер']:.2f} {total_child:.2f}")
    except FileNotFoundError:
        print("Файл products.csv не найден")


if __name__ == '__main__':
    main()