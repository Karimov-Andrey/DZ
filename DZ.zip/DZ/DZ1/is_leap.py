#17
def is_leap(year):
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

def main():
    try:
        year = int(input().strip())
        print(is_leap(year))
    except EOFError:
        pass

if __name__ == '__main__':
    main()