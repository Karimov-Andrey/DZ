#7
def main():
    a = int(input())
    b = input()
    b=b.split()
    if a == len(b):
        b = list(set(b))
        s = []
        for x in b:
            s.append(int(x))
        s.remove(max(s))
        print(max(s))

if __name__ == '__main__':
    main()