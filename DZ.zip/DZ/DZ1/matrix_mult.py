#20
def main():
    try:
        n = int(input().strip())

        A = []
        for _ in range(n):
            A.append([int(x) for x in input().split()])

        B = []
        for _ in range(n):
            B.append([int(x) for x in input().split()])

        C = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += A[i][k] * B[k][j]

        for row in C:
            print(*row)
    except EOFError:
        pass


if __name__ == '__main__':
    main()