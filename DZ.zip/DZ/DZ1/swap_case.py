#10
def main():
    try:
        s = input().strip()
        print(s.swapcase())
    except EOFError:
        pass

if __name__ == '__main__':
    main()