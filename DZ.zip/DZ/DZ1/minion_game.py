#16
def main():
    try:
        s = input().strip()
        vowels = "AEIOU"
        stuart_score = 0
        kevin_score = 0
        n = len(s)

        for i in range(n):
            if s[i] in vowels:
                kevin_score += (n - i)
            else:
                stuart_score += (n - i)

        if stuart_score > kevin_score:
            print(f"Стюарт {stuart_score}")
        elif kevin_score > stuart_score:
            print(f"Кевин {kevin_score}")
        else:
            print("Ничья")
    except EOFError:
        pass


if __name__ == '__main__':
    main()