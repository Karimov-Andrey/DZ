#5
def main():
    data = input()
    if data:
        n = int(data)
        for i in range(n):
            print(i ** 2)

if __name__ == '__main__':
    main()