#14
def main():
    try:
        data = input().split()
        if len(data) >= 2:
            print("YES" if sorted(data[0]) == sorted(data[1]) else "NO")
    except EOFError:
        pass

if __name__ == '__main__':
    main()