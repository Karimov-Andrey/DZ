#6
def main():
    data = input()
    if data:
        n = int(data)
        for i in range(1, n + 1):
            print(i, end='')
        print()

if __name__ == '__main__':
    main()