import os
import sys

if __name__ == '__main__':
    if len(sys.argv) > 1:
        target = sys.argv[1]
        found = False
        for root, dirs, files in os.walk('.'):
            if target in files:
                found = True
                try:
                    with open(os.path.join(root, target), 'r', encoding='utf-8') as f:
                        for _ in range(5):
                            line = f.readline()
                            if not line: break
                            print(line, end='')
                except Exception:
                    pass
                break
        if not found:
            print(f"Файл {target} не найден")
