import time
from datetime import datetime
import functools

def function_logger(filepath):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start_dt = datetime.now()
            start_time = time.perf_counter()
            res = '-'
            try:
                res = func(*args, **kwargs)
                return res
            finally:
                end_time = time.perf_counter()
                end_dt = datetime.now()
                with open(filepath, 'a', encoding='utf-8') as f:
                    f.write(f"{func.__name__}\n")
                    f.write(f"{start_dt.strftime('%Y-%m-%d %H:%M:%S.%f')}\n")
                    if args and kwargs: f.write(f"{args} {kwargs}\n")
                    elif args: f.write(f"{args}\n")
                    elif kwargs: f.write(f"{kwargs}\n")
                    f.write(f"{res}\n")
                    f.write(f"{end_dt.strftime('%Y-%m-%d %H:%M:%S.%f')}\n")
                    f.write(f"{end_time - start_time:.6f}\n")
        return wrapper
    return decorator
