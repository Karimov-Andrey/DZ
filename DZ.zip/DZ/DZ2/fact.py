import timeit

def fact_rec(n):
    return 1 if n <= 1 else n * fact_rec(n - 1)

def fact_it(n):
    res = 1
    for i in range(2, n + 1):
        res *= i
    return res

# Сравнение скорости: Итерационный подход (fact_it) работает быстрее рекурсивного,
# так как не тратит время и память на вызовы функций (стек вызовов).
if __name__ == '__main__':
    print("Рекурсия:", timeit.timeit("fact_rec(10)", globals=globals(), number=100000))
    print("Итерация:", timeit.timeit("fact_it(10)", globals=globals(), number=100000))
