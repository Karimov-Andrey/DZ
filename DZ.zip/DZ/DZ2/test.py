import pytest
from fact import fact_rec, fact_it
from show_employee import show_employee
from sum_and_sub import sum_and_sub
from process_list import process_list, process_list_gen
from my_sum import my_sum
from email_validation import fun
from fibonacci import fibonacci
from average_scores import compute_average_scores


@pytest.mark.parametrize("n, expected", [
    (1, 1), (2, 2), (3, 6), (4, 24), (5, 120)
])
def test_fact_rec(n, expected):
    assert fact_rec(n) == expected

@pytest.mark.parametrize("n, expected", [
    (1, 1), (2, 2), (3, 6), (4, 24), (5, 120)
])
def test_fact_it(n, expected):
    assert fact_it(n) == expected

@pytest.mark.parametrize("name, salary, expected", [
    ("Иванов", 30000, "Иванов: 30000 ₽"),
    ("Петров", None, "Петров: 100000 ₽"),
    ("Сидоров", 0, "Сидоров: 0 ₽"),
    ("Анна", 150000, "Анна: 150000 ₽"),
    ("Макс", -50, "Макс: -50 ₽")
])
def test_show_employee(name, salary, expected):
    if salary is None:
        assert show_employee(name) == expected
    else:
        assert show_employee(name, salary) == expected

@pytest.mark.parametrize("a, b, expected", [
    (5, 3, (8, 2)), (0, 0, (0, 0)), (-5, 5, (0, -10)), 
    (1.5, 0.5, (2.0, 1.0)), (-1, -1, (-2, 0)), (100, 10, (110, 90)),
    (7, 8, (15, -1)), (3.3, 1.1, (4.4, 2.2)), (9, 0, (9, 9)), (0, 9, (9, -9))
])
def test_sum_and_sub(a, b, expected):
    res = sum_and_sub(a, b)
    assert abs(res[0] - expected[0]) < 1e-9
    assert abs(res[1] - expected[1]) < 1e-9

# 26-35. Тесты process_list (list comprehension & gen)
@pytest.mark.parametrize("arr, expected", [
    ([1, 2, 3], [1, 4, 27]), 
    ([2, 4, 6], [4, 16, 36]),
    ([1, 3, 5], [1, 27, 125]),
    ([], []),
    ([0], [0])
])
def test_process_list(arr, expected):
    assert process_list(arr) == expected
    assert list(process_list_gen(arr)) == expected

# 36-45. Тесты my_sum
@pytest.mark.parametrize("args, expected", [
    ((1, 2, 3), 6), ((0,), 0), ((), 0), ((-1, 1), 0),
    ((1.5, 2.5), 4.0), ((10, 20, 30, 40), 100),
    ((-5, -5, -5), -15), ((3.14,), 3.14), ((1, -2, 3), 2), ((100,), 100)
])
def test_my_sum(args, expected):
    assert my_sum(*args) == expected

@pytest.mark.parametrize("email, expected", [
    ("lara@mospolytech.ru", True),
    ("brian-23@mospolytech.ru", True),
    ("britts_54@mospolytech.ru", True),
    ("invalid_email", False),
    ("test@domain", False),
    ("test@.com", False),
    ("@domain.com", False),
    ("test@domain.toolong", False),
    ("test!@domain.com", False),
    ("test@dom_ain.com", False)
])
def test_email_validation(email, expected):
    assert fun(email) == expected


@pytest.mark.parametrize("n, expected", [
    (1, [0]), (2, [0, 1]), (3, [0, 1, 1]), (4, [0, 1, 1, 2]), (5, [0, 1, 1, 2, 3])
])
def test_fibonacci(n, expected):
    assert fibonacci(n) == expected

def test_average_scores_1():
    assert compute_average_scores([(89, 90, 78, 93, 80), (90, 91, 85, 88, 86), (91, 92, 83, 89, 90.5)]) == (90.0, 91.0, 82.0, 90.0, 85.5)

def test_average_scores_2():
    assert compute_average_scores([(10, 10), (20, 20)]) == (15.0, 15.0)

def test_average_scores_3():
    assert compute_average_scores([(100,), (0,)]) == (50.0,)
