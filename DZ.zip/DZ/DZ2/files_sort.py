import os
import sys

if __name__ == '__main__':
    if len(sys.argv) > 1 and os.path.isdir(sys.argv[1]):
        dir_path = sys.argv[1]
        files = [f for f in os.listdir(dir_path) if os.path.isfile(os.path.join(dir_path, f))]
        files.sort(key=lambda x: (os.path.splitext(x)[1], x))
        for f in files:
            print(f)
