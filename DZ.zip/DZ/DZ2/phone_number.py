def wrapper(f):
    def fun(l):
        res = []
        for num in l:
            if len(num) > 10:
                num = num[-10:]
            elif len(num) < 10:
                res.append(num)
                continue
            res.append(f"+7 ({num[:3]}) {num[3:6]}-{num[6:8]}-{num[8:]}")
        return f(res)
    return fun

@wrapper
def sort_phone(l):
    return sorted(l)

if __name__ == '__main__':
    l = [input() for _ in range(int(input()))]
    print(*sort_phone(l), sep='\n')
