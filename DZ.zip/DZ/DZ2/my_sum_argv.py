import sys

if __name__ == '__main__':
    try:
        numbers = [float(x) for x in sys.argv[1:]]
        res = sum(numbers)
        print(int(res) if res.is_integer() else res)
    except ValueError:
        pass
