def process_list(arr):
    return [i**2 if i % 2 == 0 else i**3 for i in arr]

def process_list_gen(arr):
    for i in arr:
        yield i**2 if i % 2 == 0 else i**3
